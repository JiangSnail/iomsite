from django.apps import AppConfig


class IomsConfig(AppConfig):
    name = 'ioms'

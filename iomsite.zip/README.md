# iomsite
# 数据库设计
数据库分为4个表，
* 主表为 iom
* speciality
* subject